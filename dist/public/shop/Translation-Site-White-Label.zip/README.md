# Translation Site White-Label Template

An AI-powered translation and rewriting platform for EN↔FR, ready to deploy under your own brand.

## Quick Start

### 1. Prerequisites
- Node.js 20+
- MySQL 8.0+
- An LLM API key (OpenRouter, Anthropic, Groq, or OpenAI-compatible)

### 2. Install
```bash
unzip Translation-Site-White-Label.zip
cd app/
npm install
```

### 3. Configure Database
Create a MySQL database, then update the credentials in `server/freemium.cjs` (search for `YOUR_DB_USER` and `YOUR_DB_PASSWORD`), or set environment variables:
```
DB_HOST=localhost
DB_USER=your_db_user
DB_PASSWORD=your_db_password
DB_NAME=your_db_name
```

### 4. Start
```bash
npm start
```
The app runs on port 5000 by default.

### 5. First Login
- Go to `http://localhost:5000/#/admin`
- Default credentials: `admin` / `ChangeMe123!`
- **Change the password immediately** in the Credentials section

### 6. Configure LLM
In the admin panel, set up your LLM provider (API key, model, endpoint).

## Branding

Search for `YOUR_` placeholders throughout the code to customize:

| Placeholder | Where | What to replace with |
|---|---|---|
| `YOUR_NAME` | index.html, index.cjs | Your name or company name |
| `YOUR_CONTACT_EMAIL` | index.html, index.cjs | Your contact email(s) |
| `YOUR_LOGO_URL` | index.html (splash) | URL or base64 of your logo |
| `YOUR_DB_USER` | freemium.cjs, index.cjs | MySQL username |
| `YOUR_DB_PASSWORD` | freemium.cjs, index.cjs | MySQL password |
| `YOUR_API_KEY` | index.cjs | LLM API key (or set via admin panel) |

For detailed branding and deployment instructions, see the included **documentation PDF**.

## What's Included

```
app/                    # The deployable application
  server.js             # Entry point
  package.json          # Dependencies
  dist/                 # Server bundle + frontend
  server/               # User auth, billing, DB setup
docs/
  TextAppeal-Pro-Documentation.pdf  # Full 26-page technical guide
LICENSE.md              # Commercial license
README.md               # This file
```

## Features

- Bidirectional EN↔FR translation with LLM
- 6 editable style presets (3 per language)
- Translation memory (TMX) and glossary (CSV)
- Web terminology search
- Freemium model with Stripe billing
- User registration and authentication
- Admin panel for all configuration
- Editable splash pages (EN/FR)
- Smart Word paste (preserves formatting)
- Zero Data Retention privacy model

## Documentation

See `docs/TextAppeal-Pro-Documentation.pdf` for:
- Deployment on Hostinger, other hosts, or on-premise
- Local LLM setup for air-gapped environments
- White-label branding guide
- API reference
- Database schema
- Security considerations
- Troubleshooting

## License

See LICENSE.md. Commercial use permitted. Redistribution of the template itself is not permitted.

---

**Built by Voilà Translations** | fcouture@voilatranslations.com
