# Commercial License Agreement

## Translation Site White-Label Template

**Copyright (c) 2026 Voilà Translations. All rights reserved.**

---

### 1. Grant of License

Upon purchase, you ("Licensee") are granted a non-exclusive, non-transferable license to:

- **Deploy** this template on an unlimited number of domains and servers owned or operated by you or your organization
- **Modify** the source code, branding, design, and content to suit your needs
- **Use commercially** — you may charge your own clients for access to sites built with this template
- **Create derivative works** based on this template for your own use or your clients' use

### 2. Restrictions

You may **not**:

- **Redistribute** the template itself (modified or unmodified) as a standalone product for sale
- **Resell** the template package to others as a template or starter kit
- **Sublicense** or transfer your license to another party
- **Remove** this license file from deployments (though it need not be publicly visible)

### 3. Ownership

The original template code, architecture, and documentation remain the intellectual property of Voilà Translations. Your modifications, branding, and custom content are your own property.

### 4. Support

This license does not include technical support. Support packages may be purchased separately. The documentation included in this package is your primary resource for deployment and customization.

### 5. Warranty Disclaimer

THIS TEMPLATE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. THE LICENSOR SHALL NOT BE LIABLE FOR ANY DAMAGES ARISING FROM THE USE OF THIS TEMPLATE.

### 6. Third-Party Dependencies

This template uses open-source libraries (Express, React, mysql2, Stripe, etc.) which are subject to their own licenses (MIT, Apache 2.0, etc.). The Licensee is responsible for compliance with those licenses.

---

**Voilà Translations**
Contact: fcouture@voilatranslations.com
