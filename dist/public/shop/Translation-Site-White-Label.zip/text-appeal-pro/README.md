# Text Appeal™ Pro — White-Label Deployment Package

**Version 2.0 — March 2026**

Professional bilingual EN↔FR translation & stylistic polishing web application with 26 proprietary writing principles, real terminology database integration (TERMIUM Plus, Linguee), and Progressive Web App support.

---

## Quick Start

1. Upload all files to your Node.js hosting (Hostinger or equivalent)
2. Run `npm install`
3. Edit `server/data/db-config.json` with your MySQL credentials
4. Import `server/db-setup.sql` into your MySQL database
5. Start: `node server.js` (default port 5000)
6. Open admin panel and configure your LLM API key

## Requirements

- **Node.js** >= 20.0.0
- **MySQL** database (Hostinger compatible)
- **LLM API key** — OpenRouter (recommended), Anthropic, AWS Bedrock, or Groq

## Configuration Files

| File | Purpose |
|------|---------|
| `server/data/db-config.json` | MySQL connection (host, user, password, database) |
| `server/data/admin-config.json` | Admin settings, SMTP, "Get Your Own Site" toggle |
| `server/data/glossary.csv` | 47,497 bilingual glossary entries |
| `server/data/memory.tmx` | 18,883 translation memory units |

## Persistent Data

On first run, data files are migrated to `~/.textappeal/` in the home directory. This location survives redeployments — you will not lose your glossary, TM, or configuration when updating the app.

## Admin Panel

Access at `/admin` after starting the server.

- Default password: configure via the admin panel
- LLM provider setup (OpenRouter, Bedrock, Anthropic, Groq)
- Style prompt editor (3 styles × 2 directions)
- Glossary & TM upload
- User management & billing (Stripe)
- SMTP email configuration

## Technology Stack

- **Frontend**: React + Vite (compiled), Vanilla JS overlays, PWA
- **Backend**: Node.js / Express 5
- **Database**: MySQL
- **AI**: OpenRouter / AWS Bedrock / Anthropic (configurable)
- **Terminology**: TERMIUM Plus (Government of Canada), Linguee
- **Billing**: Stripe (freemium model)

## Documentation

See the included `TextAppeal-Pro-Documentation.pdf` for complete technical documentation.

---

© 2026 François Couture — Voilà Translations | textappeal.pro
